package workshop07.shape;

public interface Movable {

	void move(int x,int y);
}
