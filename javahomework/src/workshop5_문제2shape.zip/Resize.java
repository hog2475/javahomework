package shape;

public interface Resize {

	void setResize(int size);
}
