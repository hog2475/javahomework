package com.car;


public interface Temp {
	int getTempGage();
}
